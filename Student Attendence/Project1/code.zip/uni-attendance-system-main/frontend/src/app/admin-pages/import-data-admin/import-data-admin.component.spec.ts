import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportDataAdminComponent } from './import-data-admin.component';

describe('ImportDataAdminComponent', () => {
  let component: ImportDataAdminComponent;
  let fixture: ComponentFixture<ImportDataAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ImportDataAdminComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ImportDataAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
