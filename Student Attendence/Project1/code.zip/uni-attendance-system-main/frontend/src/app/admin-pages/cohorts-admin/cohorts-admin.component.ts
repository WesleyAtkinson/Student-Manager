import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cohorts-admin',
  templateUrl: './cohorts-admin.component.html',
  styleUrls: ['./cohorts-admin.component.scss']
})
export class CohortsAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
