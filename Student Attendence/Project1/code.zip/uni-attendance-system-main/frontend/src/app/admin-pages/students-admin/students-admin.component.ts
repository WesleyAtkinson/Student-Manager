import { Component, OnInit } from '@angular/core';

export interface Student {
  name: string;
  username: string;
  attendance: number;
}

const STUDENT_DATA: Student[] = [
  {name: 'Ross Feeley', username: 'rossfeeley', attendance: 96},
  {name: 'Monte Hellawell', username: 'montudor', attendance: 77},
  {name: 'Wes Atkinson', username: 'bigwes', attendance: 100},
  {name: 'Ammar', username: 'ammar99', attendance: 88},
];

@Component({
  selector: 'app-students-admin',
  templateUrl: './students-admin.component.html',
  styleUrls: ['./students-admin.component.scss']
})
export class StudentsAdminComponent implements OnInit {
  constructor() { }

  displayedColumns: string[] = ['name', 'username', 'attendance', 'button'];
  dataSource = STUDENT_DATA;

  ngOnInit(): void {
  }

  openAddStudentDialog() {
    console.log('openAddStudentDialog()');
  }

  openViewStudentDialog(student: Student) {
    console.log('openViewStudentDialog() + student: ', student);
  }

}
