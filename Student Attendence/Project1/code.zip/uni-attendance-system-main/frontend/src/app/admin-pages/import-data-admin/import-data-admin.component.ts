import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-import-data-admin',
  templateUrl: './import-data-admin.component.html',
  styleUrls: ['./import-data-admin.component.scss']
})
export class ImportDataAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
