import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staff-admin',
  templateUrl: './staff-admin.component.html',
  styleUrls: ['./staff-admin.component.scss']
})
export class StaffAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
