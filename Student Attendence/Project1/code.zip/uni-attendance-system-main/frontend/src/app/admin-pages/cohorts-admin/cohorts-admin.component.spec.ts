import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CohortsAdminComponent } from './cohorts-admin.component';

describe('CohortsAdminComponent', () => {
  let component: CohortsAdminComponent;
  let fixture: ComponentFixture<CohortsAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CohortsAdminComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CohortsAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
