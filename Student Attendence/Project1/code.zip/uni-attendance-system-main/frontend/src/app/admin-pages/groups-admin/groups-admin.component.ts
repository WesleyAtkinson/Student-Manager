import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-groups-admin',
  templateUrl: './groups-admin.component.html',
  styleUrls: ['./groups-admin.component.scss']
})
export class GroupsAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
