import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { catchError } from 'rxjs';
import { ApiService, Class, Student } from 'src/app/services/api.service';
import { UserListComponent } from '../user-list/user-list.component';

@Component({
  selector: 'app-class-form',
  templateUrl: './class-form.component.html',
  styleUrls: ['./class-form.component.scss']
})
export class ClassFormComponent implements OnInit {

  @Input('class') class: Class | null = null
  @Output() onComplete = new EventEmitter<Class>()

  students!: Student[]
  selectedUsers: Student[] = []
  @ViewChild('userList') userList!: UserListComponent

  form = new FormGroup({
    name: new FormControl('', [Validators.required]),
  })
  loading = false

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    if(this.class) {
      this.form.patchValue(this.class)
    }
    this.apiService.getStudents().subscribe(students => {
      this.students = students
      this.selectedUsers = students
    })
  }

  submit() {
    this.loading = true

    const details: any = {
      users: this.userList.getSelectedUsers().map(u => u.id),
      ...this.form.value
    }

    if(this.class) {
      this.apiService.updateClass(this.class.id, details).pipe(catchError(err => {
        this.loading = false
        return []
      })).subscribe(cls => {
        if(this.class) {
          this.class.name = cls.name
        }
        this.loading = false
        this.onComplete.emit(cls)
      })
    } else {
      this.apiService.createClass(details).pipe(catchError(err => {
        this.loading = false
        return []
      })).subscribe(cls => {
        this.loading = false
        this.onComplete.emit(cls)
      })
    }
  }

}
