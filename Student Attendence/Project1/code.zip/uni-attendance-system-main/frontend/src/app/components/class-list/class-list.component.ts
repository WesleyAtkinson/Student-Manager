import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { UpdateClassDialogComponent } from 'src/app/dialogs/update-class-dialog/update-class-dialog.component';
import { ApiService, Class } from 'src/app/services/api.service';

@Component({
  selector: 'app-class-list',
  templateUrl: './class-list.component.html',
  styleUrls: ['./class-list.component.scss']
})
export class ClassListComponent implements OnInit {

  @Input() classes: Class[] = []
  @Input() displayedColumns: string[] = ['name']

  constructor(private apiService: ApiService, public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  updateClass(cls: Class) {
    const dialogRef = this.dialog.open(UpdateClassDialogComponent, {
      width: '90%',
      data: {class: cls}
    })

    dialogRef.afterClosed().subscribe(cls => {
      if(cls) {
        this.classes = [...this.classes]
      }
    })
  }

  deleteClass(classId: number) {
    this.apiService.deleteClass(classId).subscribe(() => {
      this.classes = this.classes.filter(cls => cls.id !== classId)
    })
  }
}
