import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DialogData } from '../modal/modal.component';

interface Time {
  id: number;
  timeRange: string;
}

interface Group {
  id: number;
  group: string;
}

@Component({
  selector: 'app-create-new-session',
  templateUrl: './create-new-session.component.html',
  styleUrls: ['./create-new-session.component.scss']
})
export class CreateNewSessionComponent implements OnInit {

  groups: Group[] = [
    {id: 1, group: 'Maths 1'},
    {id: 2, group: 'Maths 2'},
    {id: 3, group: 'English 1'},
    {id: 4, group: 'English 2'},
  ];

  times: Time[] = [
    {id: 1, timeRange: '9:00 - 10:00'},
    {id: 2, timeRange: '10:00 - 11:00'},
    {id: 3, timeRange: '11:00 - 12:00'},
    {id: 4, timeRange: '13:00 - 14:00'},
    {id: 5, timeRange: '14:00 - 15:00'},
    {id: 6, timeRange: '15:00 - 16:00'},
  ];
  
  name: string = '';

  constructor(@Inject(MAT_DIALOG_DATA) public data: DialogData) { }

  ngOnInit(): void {
  }

}
