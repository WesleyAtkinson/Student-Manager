import { Component, Input, OnInit } from '@angular/core';
import { ApiService, AttendanceStatus, Session, Student, User } from 'src/app/services/api.service';

@Component({
  selector: 'app-attendance-list',
  templateUrl: './attendance-list.component.html',
  styleUrls: ['./attendance-list.component.scss']
})
export class AttendanceListComponent implements OnInit {

  @Input() session!: Session
  @Input() statuses: AttendanceStatus[] = []
  @Input() displayedColumns: string[] = ['name', 'attendance']

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
  }
  
  changeAttendance(status: AttendanceStatus, attended: boolean) {
    if(attended) {
      this.apiService.createAttendance({
        sessionId: this.session.id,
        userId: status.user.id
      })
        .subscribe(attendance => {
          status.attendance = attendance
        })
    } else {
      this.apiService.deleteAttendance(this.session.id, status.attendance!.id)
        .subscribe(() => {
          status.attendance = null
        })
    }
  }

}
