import { Component, Input, OnInit } from '@angular/core';
import { User } from 'src/app/services/api.service';

export interface UserWithSelect extends User {
  selected?: boolean
}

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})
export class UserListComponent implements OnInit {

  @Input() users: UserWithSelect[] = []
  @Input() selectedUsers: User[] = []
  @Input() displayedColumns: string[] = ['name']

  constructor() { }

  ngOnInit(): void {
  }

  toggleSelected(user: User, selected: boolean) {
    if(selected) {
      this.selectedUsers.push(user)
    } else {
      this.selectedUsers = this.selectedUsers.filter(u => u.id !== user.id)
    }
  }

  isSelected(user: User) {
    return this.selectedUsers.some(u => u.id === user.id)
  }
    
  getSelectedUsers() {
    return this.selectedUsers
  }

}
