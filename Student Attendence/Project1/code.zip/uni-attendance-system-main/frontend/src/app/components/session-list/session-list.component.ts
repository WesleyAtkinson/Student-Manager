import { Component, Input, OnInit } from '@angular/core';
import { Session } from 'src/app/services/api.service';

@Component({
  selector: 'app-session-list',
  templateUrl: './session-list.component.html',
  styleUrls: ['./session-list.component.scss']
})
export class SessionListComponent implements OnInit {

  @Input() sessions: Session[] = []
  @Input() displayedColumns: string[] = []

  constructor() { }

  ngOnInit(): void {
  }

}
