import { Component, Input, OnInit } from '@angular/core';
import Chart from 'chart.js/auto';
import { zip } from 'rxjs';
import { AnonymousSubject } from 'rxjs/internal/Subject';
import { Class, ApiService, Student } from 'src/app/services/api.service';

export interface StudentAttendance {
  studentName: string;
  attendance: string;
}

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.scss']
})
export class BarChartComponent implements OnInit {

  @Input() classes!: Class[];
  @Input() students!: Student[];
  @Input() studentAttendance: boolean = false;
  @Input() isTeacher: boolean = false;
  @Input() classId: number = 0;
  public chart: any;
  public data: any;
 
  constructor(private apiService: ApiService) { }

  ngOnInit(): void {

    if (this.classId != 0) {
      this.createClassStudentAttendanceChart(); // Teacher class class pages
      return;
    }

    if (this.classes && this.isTeacher) {
      this.createClassAttendanceChart(); // Teacher dashboard page
      return;
    }

    if (this.classes && !this.isTeacher) {
      this.createStudentAttendanceChart(); // Students my classes page
    }
  }

  createClassStudentAttendanceChart() {
    this.apiService.getClassStudentAttendance(this.classId).subscribe(data=> {
      this.data = {
        names: data.map((obj: any) => `${obj.student.firstName} ${obj.student.lastName}`),
        attendance: data.map((obj: any) => obj.attendance)
      }
      this.createAttendanceChart()
    });
  }

  createClassAttendanceChart() {
    const observables = this.classes.map(cls => this.apiService.getClassAttendance(cls.id))
    let attendances: number[] = []
    zip(...observables).subscribe(data => {
      attendances = data.map(attendance => attendance.classAttendance)

      this.data = {
        names: this.classes.map(cls => cls.name),
        attendance: attendances
      }
      this.createAttendanceChart()
    })
  }


  createStudentAttendanceChart() { 
    let classNames = [];
    let attendance = [];

    for (let i = 0; i < this.classes.length; i++) {
      classNames.push(this.classes[i].name);
      attendance.push(this.classes[i].personalAttendance);
    }
    this.data = {names: classNames, attendance: attendance};
    this.createAttendanceChart();
  }

  createAttendanceChart(){ 
    this.chart = new Chart("MyChart", {
      type: 'bar',

      data: { //Labels = x-axis
        labels: this.data.names, 
	       datasets: [ 
          {
            label: "Attendance", 
            data: this.data.attendance,
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(255, 205, 86, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(201, 203, 207, 0.2)'
            ],
            borderColor: [
              'rgb(255, 99, 132)',
              'rgb(255, 205, 86)',
              'rgb(54, 162, 235)',
              'rgb(201, 203, 207)'
            ],
            borderWidth: 1,
          }
        ]
      },
      options: {
        scales: {
          y: {
              suggestedMin: 0,
              suggestedMax: 100
          }
        },
        aspectRatio:2,
        plugins: {
          legend: {
              display: false,
          },
        }
      }
    });
  }
}
