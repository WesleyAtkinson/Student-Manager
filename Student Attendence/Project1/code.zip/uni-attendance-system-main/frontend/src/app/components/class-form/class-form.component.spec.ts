import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { JWT_OPTIONS, JwtHelperService } from '@auth0/angular-jwt';

import { ClassFormComponent } from './class-form.component';

fdescribe('ClassFormComponent', () => {
  let component: ClassFormComponent;
  let fixture: ComponentFixture<ClassFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClassFormComponent ],
      imports: [HttpClientTestingModule],
      providers: [
        { provide: JWT_OPTIONS, useValue: JWT_OPTIONS },
        JwtHelperService
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClassFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have a form with 2 controls', () => {
    expect(component.form.contains('name')).toBeTruthy();
  });

  it('should check that class name is required', () => {
    let className = component.form.controls['name'];
    expect(className.valid).toBeFalsy();
    expect(className.errors!['required']).toBeTruthy();
  });

  it('should set class name and be valid', () => {
    let className = component.form.controls['name'];
    className.setValue('Software Engineering');
    expect(className.valid).toBeTruthy();
  })

  it('should be a valid form when all fields are filled out correctly', () => {
    component.form.controls['name'].setValue('Maths');
    expect(component.form.valid).toBeTruthy();
  })
});
