import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Component, OnInit } from '@angular/core';
import { Observable, map, shareReplay } from 'rxjs';
import { AuthService, LoginState } from 'src/app/auth/auth.service';

interface NavigationItem {
  text: string
  icon: string
  link: string
  exact?: boolean
  notifications?: { show: boolean, count?: number }
}

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {

  loginState!: LoginState

  title = 'Attendance Tracker'
  mainLinks: NavigationItem[] = []


  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );

  constructor(private authService: AuthService, private breakpointObserver: BreakpointObserver) { }

  ngOnInit(): void {
    this.authService.loginState.subscribe(loginState => {
      this.loginState = loginState
      this.generateLinks()
    })
  }

  generateLinks() {
    if(!this.loginState.profile) {
      this.mainLinks = []
      return
    }
    
    const role = this.loginState.profile.role

    if(role === 'student') {
      this.mainLinks = [
        { text: 'Home', icon: 'home', link: '/student-dashboard', exact: true },
        { text: 'Classes', icon: 'school', link: '/my-classes' },
        { text: 'Profile', icon: 'person', link: '/profile' },
      ]
    } else if(role === 'teacher') {
      this.mainLinks = [
        { text: 'Home', icon: 'home', link: '/teacher-dashboard', exact: true },
        { text: 'Profile', icon: 'person', link: '/profile' },
      ]
    } else if(role === 'admin') {
      this.mainLinks = [
        { text: 'Home', icon: 'home', link: '/teacher-dashboard', exact: true },
        { text: 'Profile', icon: 'person', link: '/profile' },
      ]
    }
  }

  logout() {
    this.authService.logout()
  }

  toggleRole() {
    this.authService.toggleRole()
  }

}
