import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { catchError } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-code-form',
  templateUrl: './code-form.component.html',
  styleUrls: ['./code-form.component.scss']
})
export class CodeFormComponent implements OnInit {

  form = new FormGroup({
    code: new FormControl('', [Validators.required])
  })
  feedback: string = ''

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
  }

  submit() {
    this.feedback = ''

    const code = this.form.value.code ?? ''
    this.apiService.useAttendanceCode(code).pipe(catchError(err => {
      this.feedback = 'Invalid code'
      return []
    })).subscribe(attendance => {
      this.feedback = 'Attendance recorded!'
    })
  }

}
