import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Class } from 'src/app/services/api.service';
import { CreateNewSessionComponent } from '../create-new-session/create-new-session.component';

@Component({
  selector: 'app-class-tile',
  templateUrl: './class-tile.component.html',
  styleUrls: ['./class-tile.component.scss']
})
export class ClassTileComponent implements OnInit {

  @Input('subject') class!: Class;
  @Input('isStudent') isStudent!: boolean;
  
  constructor(private router : Router, public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  navigatePreviousSessions(){
    this.router.navigate(['/previous-sessions'], {queryParams: {classId: this.class.id}} );
  }

  createNewSession() {
    const dialogRef = this.dialog.open(CreateNewSessionComponent, {
      width: '40%',
      data: {class: this.class},
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });

  }

}
