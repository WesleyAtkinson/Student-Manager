import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AdminDashboardComponent } from './admin-pages/admin-dashboard/admin-dashboard.component';
import { MatCardModule } from '@angular/material/card';
import { StudentsAdminComponent } from './admin-pages/students-admin/students-admin.component';
import { StaffAdminComponent } from './admin-pages/staff-admin/staff-admin.component';
import { GroupsAdminComponent } from './admin-pages/groups-admin/groups-admin.component';
import { CohortsAdminComponent } from './admin-pages/cohorts-admin/cohorts-admin.component';
import { ImportDataAdminComponent } from './admin-pages/import-data-admin/import-data-admin.component';
import { MaterialModule } from './material/material.module';
import { StudentDashboardComponent } from './student-pages/student-dashboard/student-dashboard.component';
import { MyClassesComponent } from './student-pages/my-classes/my-classes.component';
import { ClassTileComponent } from './components/class-tile/class-tile.component';
import { PreviousSessionsComponent } from './pages/previous-sessions/previous-sessions.component';
import { BarChartComponent } from './components/bar-chart/bar-chart.component';
import { ModalComponent } from './components/modal/modal.component';
import { TeacherDashboardComponent } from './staff-pages/teacher-dashboard/teacher-dashboard.component';
import { CreateNewSessionComponent } from './components/create-new-session/create-new-session.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SessionAttendanceComponent } from './staff-pages/session-attendance/session-attendance.component';
import { AuthModule } from './auth/auth.module';
import { HttpClientModule } from '@angular/common/http';
import { JwtModule } from '@auth0/angular-jwt';
import { getToken } from './lib/utils';
import { environment } from 'src/environments/environment';
import { NavbarComponent } from './components/navbar/navbar.component';
import { HomePageComponent } from './pages/home-page/home-page.component';
import { UserListComponent } from './components/user-list/user-list.component';
import { AttendanceListComponent } from './components/attendance-list/attendance-list.component';
import { ClassListComponent } from './components/class-list/class-list.component';
import { ClassFormComponent } from './components/class-form/class-form.component';
import { CreateClassDialogComponent } from './dialogs/create-class-dialog/create-class-dialog.component';
import { ClassPageComponent } from './staff-pages/class-page/class-page.component';
import { SessionListComponent } from './components/session-list/session-list.component';
import { SessionPageComponent } from './staff-pages/session-page/session-page.component';
import { CodeFormComponent } from './components/code-form/code-form.component';
import { UpdateClassDialogComponent } from './dialogs/update-class-dialog/update-class-dialog.component';
import { ClassAttendanceDialogComponent } from './dialogs/class-attendance-dialog/class-attendance-dialog.component';
import { StudentAttendanceDialogComponent } from './dialogs/student-attendance-dialog/student-attendance-dialog.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { ProfilePageComponent } from './pages/profile-page/profile-page.component';


@NgModule({
  declarations: [
    AppComponent,
    AdminDashboardComponent,
    StudentsAdminComponent,
    StaffAdminComponent,
    GroupsAdminComponent,
    CohortsAdminComponent,
    ImportDataAdminComponent,
    StudentDashboardComponent,
    MyClassesComponent,
    ClassTileComponent,
    PreviousSessionsComponent,
    BarChartComponent,
    ModalComponent,
    NavbarComponent,
    HomePageComponent,
    TeacherDashboardComponent,
    CreateNewSessionComponent,
    SessionAttendanceComponent,
    UserListComponent,
    AttendanceListComponent,
    ClassListComponent,
    ClassFormComponent,
    CreateClassDialogComponent,
    ClassPageComponent,
    SessionListComponent,
    SessionPageComponent,
    CodeFormComponent,
    UpdateClassDialogComponent,
    ClassAttendanceDialogComponent,
    StudentAttendanceDialogComponent,
    ProfilePageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    MaterialModule,
    FormsModule,
    HttpClientModule,
    JwtModule.forRoot({
      config: {
        tokenGetter: getToken,
        allowedDomains: [environment.baseApiUrl.replace(/^https?:\/\//, '')]
      },
    }),
    AuthModule,
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: environment.production,
      // Register the ServiceWorker as soon as the application is stable
      // or after 30 seconds (whichever comes first).
      registrationStrategy: 'registerWhenStable:30000'
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
