class Adapter {
  static getAdapter() {
    // If in iframe use memory adapter
    if(!(window===window.parent)) return MemoryAdapter
    else return LocalStorageAdapter
  }
}

class MemoryAdapter {
  static accessToken: string = ''

  static getToken() {
    return this.accessToken || null
  }

  static setToken(token: string) {
    this.accessToken = token
  }

  static removeToken() {
    this.accessToken = ''
  }
}

class LocalStorageAdapter {
  static getToken() {
    return localStorage.getItem('access_token')
  }

  static setToken(token: string) {
    return localStorage.setItem('access_token', token)
  }

  static removeToken() {
    return localStorage.removeItem('access_token')
  }
}


export function getToken() {
  let adapter = Adapter.getAdapter()
  return adapter.getToken()
}

export function setToken(token: string) {
  let adapter = Adapter.getAdapter()
  return adapter.setToken(token)
}

export function removeToken() {
  let adapter = Adapter.getAdapter()
  return adapter.removeToken()
}
