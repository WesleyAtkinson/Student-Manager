import { Component, OnInit } from '@angular/core';
import { ApiService, Student } from 'src/app/services/api.service';


@Component({
  selector: 'app-session-attendance',
  templateUrl: './session-attendance.component.html',
  styleUrls: ['./session-attendance.component.scss']
})
export class SessionAttendanceComponent implements OnInit {

  students: Student[] = []
  
  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.apiService.getStudents().subscribe(students => {
      this.students = students
    })
  }

}
