import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ModalComponent } from 'src/app/components/modal/modal.component';
import { ClassAttendanceDialogComponent } from 'src/app/dialogs/class-attendance-dialog/class-attendance-dialog.component';
import { CreateClassDialogComponent } from 'src/app/dialogs/create-class-dialog/create-class-dialog.component';
import { StudentAttendanceDialogComponent } from 'src/app/dialogs/student-attendance-dialog/student-attendance-dialog.component';
import { ApiService, Class, Student } from 'src/app/services/api.service';

@Component({
  selector: 'app-teacher-dashboard',
  templateUrl: './teacher-dashboard.component.html',
  styleUrls: ['./teacher-dashboard.component.scss']
})
export class TeacherDashboardComponent implements OnInit {

  classes: Class[] = []
  students: Student[] = []

  constructor(private apiService: ApiService, public dialog: MatDialog) { }

  ngOnInit(): void {
    this.apiService.getStudents().subscribe(students => {
      this.students = students
    })
    this.apiService.getClasses().subscribe(classes => {
      this.classes = classes
    })
  }

  visualiseClassAttendance() {
    const dialogRef = this.dialog.open(ClassAttendanceDialogComponent, {
      width: '90%',
      data: { classes: this.classes },
    })

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed')
    })
  }

  createClass() {
    const dialogRef = this.dialog.open(CreateClassDialogComponent, {
      width: '90%'
    })

    dialogRef.afterClosed().subscribe(cls => {
      if(cls) {
        this.classes = [...this.classes, cls]
      }
    })
  }

}
