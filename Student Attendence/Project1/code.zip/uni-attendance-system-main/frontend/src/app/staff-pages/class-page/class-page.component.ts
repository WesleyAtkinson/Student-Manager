import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentAttendanceDialogComponent } from 'src/app/dialogs/student-attendance-dialog/student-attendance-dialog.component';
import { ApiService, Class, Session } from 'src/app/services/api.service';

@Component({
  selector: 'app-class-page',
  templateUrl: './class-page.component.html',
  styleUrls: ['./class-page.component.scss']
})
export class ClassPageComponent implements OnInit {
  id: any
  cls!: Class
  sessions: Session[] = []

  constructor(private route: ActivatedRoute, private router: Router, private apiService: ApiService, public dialog: MatDialog) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      const id = params['id']

      if(id) {
        this.id = id
        this.getClass()
        this.getSessions()
      }
    })
  }

  visualiseStudentAttendance() {
    const dialogRef = this.dialog.open(StudentAttendanceDialogComponent, {
      width: '90%',
      data: {classId: this.cls.id},
    })

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed')
    })
  }

  getClass() {
    this.apiService.getClass(this.id).subscribe(cls => {
      this.cls = cls
    })
  }

  getSessions() {
    this.apiService.getSessions(this.id).subscribe(sessions => {
      this.sessions = sessions.reverse()
      console.log(this.sessions)
    })
  }

  createSession() {
    this.apiService.createSession({ classId: this.id }).subscribe(session => {
      this.sessions = [session, ...this.sessions]
      this.router.navigate(['/staff', 'session', session.id])
    })
  }

}
