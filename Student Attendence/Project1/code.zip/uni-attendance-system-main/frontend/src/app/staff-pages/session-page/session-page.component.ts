import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService, AttendanceStatus, Session, Student } from 'src/app/services/api.service';

@Component({
  selector: 'app-session-page',
  templateUrl: './session-page.component.html',
  styleUrls: ['./session-page.component.scss']
})
export class SessionPageComponent implements OnInit {

  id: any
  session!: Session
  statuses: AttendanceStatus[] = []

  constructor(private route: ActivatedRoute, private apiService: ApiService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      const id = params['id']

      if(id) {
        this.id = id
        this.getClass()
        this.getStudents()
      }
    })
  }

  getClass() {
    this.apiService.getSession(this.id).subscribe(session => {
      this.session = session
    })
  }

  getStudents() {
    this.apiService.getAttendanceStatus(this.id).subscribe(statuses => {
      this.statuses = statuses
    })
  }

}
