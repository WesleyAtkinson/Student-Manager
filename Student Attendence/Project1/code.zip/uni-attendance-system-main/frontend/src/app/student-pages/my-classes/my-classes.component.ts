import { Component, Input, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BarChartComponent } from 'src/app/components/bar-chart/bar-chart.component';
import { ModalComponent } from 'src/app/components/modal/modal.component';
import { ApiService, Class } from 'src/app/services/api.service';

@Component({
  selector: 'app-my-classes',
  templateUrl: './my-classes.component.html',
  styleUrls: ['./my-classes.component.scss']
})

export class MyClassesComponent implements OnInit {

  classes: Class[] = []

  constructor(private apiService: ApiService, public dialog: MatDialog) { }

  ngOnInit(): void {
    this.apiService.getClasses().subscribe(classes => {
      this.classes = classes
      this.getClassAttendance();
    })
  }

  getClassAttendance(){
    this.classes.forEach(cls => {
      this.apiService.getClassAttendance(cls.id).subscribe(attendance => {
        cls.personalAttendance = attendance.personalAttendance
      })
    })
  }

  visualiseData() {
    const dialogRef = this.dialog.open(ModalComponent, {
      width: '90%',
      data: {classes: this.classes},
    })

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed')
    })
  }

}
