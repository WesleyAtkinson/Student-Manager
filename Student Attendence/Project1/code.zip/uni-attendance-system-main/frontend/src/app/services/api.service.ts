import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

export interface User {
  id: number
  email: string
  firstName: string
  lastName: string
  role: 'student' | 'teacher' | 'admin'
}

export interface Student extends User {
  role: 'student'
}

export interface Teacher extends User {
  role: 'teacher'
}

export interface Admin extends User {
  role: 'admin'
}

export interface Class {
  id: number
  name: string
  personalAttendance?: number
  classAttendance?: number
}

export interface Session {
  id: number
  createdAt: string
  cls: Class
  code: string
  attended: boolean
}

export interface Attendance {
  id: number
  createdAt: string
}

export interface AttendanceStatus {
  user: Student
  attendance: Attendance | null
}

export interface ClassAttendance {
  personalAttendance: number
  classAttendance: number
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }

  getStudents() {
    return this.http.get<Student[]>(`${environment.baseApiUrl}/users/students`)
  }

  getTeachers() {
    return this.http.get<Teacher[]>(`${environment.baseApiUrl}/users/teachers`)
  }

  getAdmins() {
    return this.http.get<Admin[]>(`${environment.baseApiUrl}/users/admins`)
  }

  getClasses() {
    return this.http.get<Class[]>(`${environment.baseApiUrl}/classes`)
  }

  getClass(id: any) {
    return this.http.get<Class>(`${environment.baseApiUrl}/classes/${id}`)
  }

  createClass(details: { name: string }) {
    return this.http.post<Class>(`${environment.baseApiUrl}/classes`, details)
  }

  updateClass(id: any, cls: Class) {
    return this.http.put<Class>(`${environment.baseApiUrl}/classes/${id}`, cls)
  }

  deleteClass(classId: number) {
    return this.http.delete(`${environment.baseApiUrl}/classes/${classId}/`)
  }

  getSessions(classId: any) {
    return this.http.get<Session[]>(`${environment.baseApiUrl}/sessions`, { params: { classId } })
  }

  getSession(id: any) {
    return this.http.get<Session>(`${environment.baseApiUrl}/sessions/${id}`)
  }

  createSession(details: { classId: number }) {
    return this.http.post<Session>(`${environment.baseApiUrl}/sessions`, details)
  }

  getAttendanceStatus(sessionId: any) {
    return this.http.get<AttendanceStatus[]>(`${environment.baseApiUrl}/sessions/${sessionId}/status`)
  }

  useAttendanceCode(code: string) {
    return this.http.post<Attendance>(`${environment.baseApiUrl}/attendance`, { code })
  }

  createAttendance(details: { sessionId: number, userId: number }) {
    const sessionId: any = details.sessionId
    return this.http.post<Attendance>(`${environment.baseApiUrl}/sessions/${sessionId}/attendance`, details)
  }

  deleteAttendance(sessionId: any, attendanceId: any) {
    return this.http.delete(`${environment.baseApiUrl}/sessions/${sessionId}/attendance/${attendanceId}/`)
  }

  getClassAttendance(classId: any) {
    return this.http.get<ClassAttendance>(`${environment.baseApiUrl}/classes/${classId}/attendance`)
  }

  getClassStudentAttendance(classId: any) {
    return this.http.get<any>(`${environment.baseApiUrl}/classes/${classId}/student-attendance`)
  }
}
