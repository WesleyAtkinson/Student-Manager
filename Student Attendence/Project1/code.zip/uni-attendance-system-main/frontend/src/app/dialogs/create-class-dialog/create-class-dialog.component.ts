import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Class } from 'src/app/services/api.service';

@Component({
  selector: 'app-create-class-dialog',
  templateUrl: './create-class-dialog.component.html',
  styleUrls: ['./create-class-dialog.component.scss']
})
export class CreateClassDialogComponent implements OnInit {

  constructor(private dialog: MatDialogRef<CreateClassDialogComponent>) { }

  ngOnInit(): void {
  }

  closeDialog(result: Class | null = null) {
    this.dialog.close(result)
  }

}
