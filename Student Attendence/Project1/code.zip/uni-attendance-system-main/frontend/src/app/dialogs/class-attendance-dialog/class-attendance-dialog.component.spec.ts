import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClassAttendanceDialogComponent } from './class-attendance-dialog.component';

describe('ClassAttendanceDialogComponent', () => {
  let component: ClassAttendanceDialogComponent;
  let fixture: ComponentFixture<ClassAttendanceDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClassAttendanceDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClassAttendanceDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
