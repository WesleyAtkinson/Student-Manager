import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentAttendanceDialogComponent } from './student-attendance-dialog.component';

describe('StudentAttendanceDialogComponent', () => {
  let component: StudentAttendanceDialogComponent;
  let fixture: ComponentFixture<StudentAttendanceDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentAttendanceDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StudentAttendanceDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
