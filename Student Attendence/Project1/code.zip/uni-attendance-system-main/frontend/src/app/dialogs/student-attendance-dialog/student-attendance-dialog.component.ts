import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DialogData } from 'src/app/components/modal/modal.component';
import { Student } from 'src/app/services/api.service';
import { CreateClassDialogComponent } from '../create-class-dialog/create-class-dialog.component';

@Component({
  selector: 'app-student-attendance-dialog',
  templateUrl: './student-attendance-dialog.component.html',
  styleUrls: ['./student-attendance-dialog.component.scss']
})
export class StudentAttendanceDialogComponent implements OnInit {

  constructor(private dialog: MatDialogRef<CreateClassDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: DialogData) { }

  classId!: number;

  ngOnInit(): void {
    this.classId = this.data.classId
    console.log(this.classId)
  }
}
