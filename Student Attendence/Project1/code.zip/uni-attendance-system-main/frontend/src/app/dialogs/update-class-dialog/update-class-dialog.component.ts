import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DialogData } from 'src/app/components/modal/modal.component';
import { Class } from 'src/app/services/api.service';
import { CreateClassDialogComponent } from '../create-class-dialog/create-class-dialog.component';

@Component({
  selector: 'app-update-class-dialog',
  templateUrl: './update-class-dialog.component.html',
  styleUrls: ['./update-class-dialog.component.scss']
})
export class UpdateClassDialogComponent implements OnInit {

  constructor(private dialog: MatDialogRef<CreateClassDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: DialogData) { }

  class: Class = this.data.class;

  ngOnInit(): void {
    console.log(this.class)
  }

  closeDialog(result: Class | null = null) {
    this.dialog.close(result)
  }
}
