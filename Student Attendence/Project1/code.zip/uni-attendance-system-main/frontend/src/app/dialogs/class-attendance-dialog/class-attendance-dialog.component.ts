import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DialogData } from 'src/app/components/modal/modal.component';
import { Class } from 'src/app/services/api.service';
import { CreateClassDialogComponent } from '../create-class-dialog/create-class-dialog.component';

@Component({
  selector: 'app-class-attendance-dialog',
  templateUrl: './class-attendance-dialog.component.html',
  styleUrls: ['./class-attendance-dialog.component.scss']
})
export class ClassAttendanceDialogComponent implements OnInit {

  constructor(private dialog: MatDialogRef<CreateClassDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: DialogData) { }

  classes!: Class[];

  ngOnInit(): void {
    this.classes = this.data.classes
  }

  closeDialog(result: Class | null = null) {
    this.dialog.close(result)
  }
}
