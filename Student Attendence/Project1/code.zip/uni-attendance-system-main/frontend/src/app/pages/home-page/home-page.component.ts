import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth/auth.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit {

  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    this.authService.loginState.subscribe(loginState => {
      if(!loginState.isLoggedIn) {
        this.router.navigate(['/auth/login'], { replaceUrl: true })
        return
      }

      const role = loginState.profile?.role
      if(role === 'student') {
        this.router.navigate(['/student-dashboard'], { replaceUrl: true })
      } else if(role === 'teacher') {
        this.router.navigate(['/teacher-dashboard'], { replaceUrl: true })
      } else if(role === 'admin') {
        this.router.navigate(['/admin-dashboard'], { replaceUrl: true })
      }
    })
  }

}
