import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { take } from 'rxjs';
import { AuthService } from 'src/app/auth/auth.service';
import { ModalComponent } from 'src/app/components/modal/modal.component';
import { ApiService, Class, Session } from 'src/app/services/api.service';


const SESSION_DATA: Session[] = [
  // {id: 1, date: '08/11/2022', time: '14:00-15:00', attended: true, attendance: 100},
  // {id: 2, date: '03/11/2022', time: '14:00-15:00', attended: true, attendance: 95},
  // {id: 3, date: '02/11/2022', time: '14:00-15:00', attended: false, attendance: 89},
  // {id: 4, date: '01/11/2022', time: '14:00-15:00', attended: true, attendance: 92},
];

@Component({
  selector: 'app-previous-sessions',
  templateUrl: './previous-sessions.component.html',
  styleUrls: ['./previous-sessions.component.scss']
})
export class PreviousSessionsComponent implements OnInit {

  userId: number = 0;
  class?: Class;
  classId!: number;
  attendance: number = 0;
  isStudent: boolean = true;
  sessions: Session[] = [];
  displayedColumns: string[] = ['date', 'time', 'attendance'];

  constructor(private authService: AuthService, private apiService: ApiService, private route: ActivatedRoute, private router : Router, private dialog: MatDialog) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe((params: any) => {
      this.classId = params['classId'];
    })

    this.authService.loginState.subscribe(state => {
      if(!state.profile) return
      this.userId = state.profile.id || 0;
      this.isStudent = state.profile.role == 'student';

      if(this.isStudent) {
        this.displayedColumns = ['date', 'time', 'attended']
      } else {
        this.displayedColumns = ['date', 'time', 'attendance', 'actions']
      }
    })

    this.apiService.getClass(this.classId).subscribe((data: any) => {
      this.class = data;
    })

    this.apiService.getClassAttendance(this.classId).subscribe(data => {
      if(this.isStudent) this.attendance = data.personalAttendance;
      else this.attendance = data.classAttendance;
    })

    this.apiService.getSessions(this.classId).subscribe(sessions => {
      this.sessions = sessions;
      for (let i = 0; i < this.sessions.length; i++) {
        this.apiService.getAttendanceStatus(this.sessions[i].id).subscribe((status: any) => {
          for (let j = 0; j < status.length; j++) {
            if (status[j].user.id == this.userId && status[j].attendance != null) {
              this.sessions[i].attended = true;
            }
          }
        })
      }
    })
  }

  generateReport() {
    // open modal that contains a bar chart of students attendance in % for the subject
    
    const dialogRef = this.dialog.open(ModalComponent, {
      width: '90%',
      data: {studentAttendance: true},
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }
}
