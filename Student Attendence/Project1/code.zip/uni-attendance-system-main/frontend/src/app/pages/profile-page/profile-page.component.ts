import { Component, OnInit } from '@angular/core';
import { AuthService, Profile } from 'src/app/auth/auth.service';
import { User } from 'src/app/services/api.service';

@Component({
  selector: 'app-profile-page',
  templateUrl: './profile-page.component.html',
  styleUrls: ['./profile-page.component.scss']
})
export class ProfilePageComponent implements OnInit {

  profile!: Profile

  constructor(private authService: AuthService) { }

  ngOnInit(): void {
    this.authService.getProfile().subscribe(profile => {
      this.profile = profile
    })
  }

}
