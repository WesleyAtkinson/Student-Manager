import { group } from '@angular/animations';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminDashboardComponent } from './admin-pages/admin-dashboard/admin-dashboard.component';
import { CohortsAdminComponent } from './admin-pages/cohorts-admin/cohorts-admin.component';
import { GroupsAdminComponent } from './admin-pages/groups-admin/groups-admin.component';
import { ImportDataAdminComponent } from './admin-pages/import-data-admin/import-data-admin.component';
import { StaffAdminComponent } from './admin-pages/staff-admin/staff-admin.component';
import { StudentsAdminComponent } from './admin-pages/students-admin/students-admin.component';
import { AuthGuard } from './auth/auth.guard';
import { HomePageComponent } from './pages/home-page/home-page.component';
import { PreviousSessionsComponent } from './pages/previous-sessions/previous-sessions.component';
import { ProfilePageComponent } from './pages/profile-page/profile-page.component';
import { ClassPageComponent } from './staff-pages/class-page/class-page.component';
import { SessionAttendanceComponent } from './staff-pages/session-attendance/session-attendance.component';
import { SessionPageComponent } from './staff-pages/session-page/session-page.component';
import { TeacherDashboardComponent } from './staff-pages/teacher-dashboard/teacher-dashboard.component';
import { MyClassesComponent } from './student-pages/my-classes/my-classes.component';
import { StudentDashboardComponent } from './student-pages/student-dashboard/student-dashboard.component';

const routes: Routes = [
  { path: 'auth', loadChildren: () => import('./auth/auth-routing.module').then(m => m.AuthRoutingModule) },
  { path: '', component: HomePageComponent, pathMatch: 'full' },
  { path: 'profile', component: ProfilePageComponent, canActivate: [AuthGuard] },
  { path: 'admin-dashboard', component: AdminDashboardComponent, canActivate: [AuthGuard] },
  { path: 'students-admin', component: StudentsAdminComponent, canActivate: [AuthGuard]  },
  { path: 'staff-admin', component: StaffAdminComponent, canActivate: [AuthGuard]  },
  { path: 'groups-admin', component: GroupsAdminComponent, canActivate: [AuthGuard]  },
  { path: 'cohorts-admin', component: CohortsAdminComponent, canActivate: [AuthGuard]  },
  { path: 'import-data-admin', component: ImportDataAdminComponent, canActivate: [AuthGuard]  },
  { path: 'student-dashboard', component: StudentDashboardComponent, canActivate: [AuthGuard]  },
  { path: 'my-classes', component: MyClassesComponent, canActivate: [AuthGuard]  },
  { path: 'previous-sessions', component: PreviousSessionsComponent, canActivate: [AuthGuard]  },
  { path: 'teacher-dashboard', component: TeacherDashboardComponent, canActivate: [AuthGuard]  },
  { path: 'session-attendance', component: SessionAttendanceComponent, canActivate: [AuthGuard]  },
  { path: 'staff/class/:id', component: ClassPageComponent, canActivate: [AuthGuard]  },
  { path: 'staff/session/:id', component: SessionPageComponent, canActivate: [AuthGuard]  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
