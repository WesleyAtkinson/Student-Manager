import { HttpClientTestingModule  } from '@angular/common/http/testing';
import { JwtHelperService, JWT_OPTIONS  } from '@auth0/angular-jwt';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterPageComponent } from './register-page.component';

fdescribe('RegisterPageComponent', () => {
  let component: RegisterPageComponent;
  let fixture: ComponentFixture<RegisterPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisterPageComponent ],
      imports: [HttpClientTestingModule],
      providers: [
        { provide: JWT_OPTIONS, useValue: JWT_OPTIONS },
        JwtHelperService
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have a form with 4 controls', () => {
    expect(component.registerForm.contains('email')).toBeTruthy();
    expect(component.registerForm.contains('firstName')).toBeTruthy();
    expect(component.registerForm.contains('lastName')).toBeTruthy();
    expect(component.registerForm.contains('password')).toBeTruthy();
  });

  it('should check that email is required', () => {
    let email = component.registerForm.controls['email'];
    expect(email.valid).toBeFalsy();
    expect(email.errors!['required']).toBeTruthy();
  });

  it('should check that firstName is required', () => {
    let firstName = component.registerForm.controls['firstName'];
    expect(firstName.valid).toBeFalsy();
    expect(firstName.errors!['required']).toBeTruthy();
  });

  it('should check that lastName is required', () => {
    let lastName = component.registerForm.controls['lastName'];
    expect(lastName.valid).toBeFalsy();
    expect(lastName.errors!['required']).toBeTruthy();
  });

  it('should check that password is required', () => {
    let password = component.registerForm.controls['password'];
    expect(password.valid).toBeFalsy();
    expect(password.errors!['required']).toBeTruthy();
  }); 

  it('should set firstName and be valid', () => {
    let firstName = component.registerForm.controls['firstName'];
    firstName.setValue('John');
    expect(firstName.valid).toBeTruthy();
  })

  it('should set lastName and be valid', () => {
    let lastName = component.registerForm.controls['lastName'];
    lastName.setValue('Smith');
    expect(lastName.valid).toBeTruthy();
  })

  it('should set email and be valid', () => {
    let email = component.registerForm.controls['email'];
    email.setValue('test@gmail.com');
    expect(email.valid).toBeTruthy();
  })

  it('should set password and be valid', () => {
    let password = component.registerForm.controls['password'];
    password.setValue('Password19666');
    expect(password.valid).toBeTruthy();
  })

  it('should set email and be invalid', () => {
    let email = component.registerForm.controls['email'];
    email.setValue('testgmail.com');
    expect(email.valid).toBeFalsy();
  })

  it('should be a valid form when all fields are filled out correctly', () => {
    component.registerForm.controls['firstName'].setValue('John');
    component.registerForm.controls['lastName'].setValue('Smith');
    component.registerForm.controls['email'].setValue('stranger@gmail.com');
    component.registerForm.controls['password'].setValue('Password19666');
    expect(component.registerForm.valid).toBeTruthy();
  })
});
