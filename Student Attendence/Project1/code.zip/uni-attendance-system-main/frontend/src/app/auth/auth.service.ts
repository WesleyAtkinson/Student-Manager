import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { BehaviorSubject, throwError } from 'rxjs';
import { catchError, share } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { removeToken, setToken } from '../lib/utils';

export interface LoginResponse {
  access_token: string
}

export interface Profile {
  id?: number
  email?: string
  firstName?: string
  lastName?: string
  isActive?: boolean
  role?: 'student' | 'teacher' | 'admin'
}

export interface LoginState {
  isLoggedIn: boolean
  profile?: Profile | null
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  loginState: BehaviorSubject<LoginState> = new BehaviorSubject<LoginState>({ isLoggedIn: this.isLoggedIn() })
  currentProfile: Profile | null = null

  constructor(private httpClient: HttpClient, private jwtHelperService: JwtHelperService, private router: Router) {
    this.updateLoginState()
  }

  private updateLoginState() {
    let loginState: LoginState = {
      isLoggedIn: this.isLoggedIn(),
      profile: this.currentProfile
    }

    if(!loginState.profile) {
      this.getProfile().subscribe(profile => {
        this.currentProfile = profile
        loginState.profile = profile
        this.loginState.next(loginState)
      })
    }

    this.loginState.next(loginState)
  }

  attemptLogin(username: string, password: string) {
    let observable = this.httpClient.post<LoginResponse>(`${environment.baseApiUrl}/auth/login`, {
      username,
      password
    }).pipe(share())

    observable.pipe(
      catchError(err => {
        return throwError(err)
      })
    ).subscribe(response => {
      if(response.access_token) {
        setToken(response.access_token)
        this.updateLoginState()
      }
    })

    return observable
  }

  logout(redirect: boolean = true) {
    removeToken()
    this.currentProfile = null

    this.updateLoginState()

    if(redirect) {
      this.router.navigate(['/auth/login'])
    }
  }

  getProfile() {
    return this.httpClient.get<Profile>(`${environment.baseApiUrl}/auth/profile`)
  }

  updateProfile(profile: Profile) {
    return this.httpClient.put('http://localhost:3000/settings/profile', profile);
  }

  isLoggedIn() {
    if(this.jwtHelperService.tokenGetter() ?? null !== null) {
      return !this.jwtHelperService.isTokenExpired()
    }
    return false
  }

  createNewAccount(options: any) {
    return this.httpClient.post(`${environment.baseApiUrl}/auth/register`, options)
  }

  toggleRole(redirect: boolean = true) {
    this.httpClient.post(`${environment.baseApiUrl}/toggle-role`, {}).subscribe(() => {
      this.getProfile().subscribe(profile => {
        this.currentProfile = profile
        this.updateLoginState()

        if(redirect) {
          this.router.navigate(['/'])
        }
      })
    })
  }
}
