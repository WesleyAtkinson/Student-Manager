import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-register-page',
  templateUrl: './register-page.component.html',
  styleUrls: ['./register-page.component.scss']
})
export class RegisterPageComponent implements OnInit {

  registerForm = new FormGroup({
    firstName: new FormControl('', [Validators.required]),
    lastName: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required])
  })

  constructor(private authService: AuthService, private router: Router) { }

  static getTitle() {
    return 'Sign Up'
  }

  ngOnInit(): void {
  }

  onSubmit() {
    if(!this.registerForm.valid) return

    this.authService.createNewAccount(
      this.registerForm.value
    ).pipe(
      catchError(err => {
        return throwError(err)
      })
    ).subscribe(result => {
      console.log(result)
      this.router.navigate(['/auth/login'])
    })
  }

}
