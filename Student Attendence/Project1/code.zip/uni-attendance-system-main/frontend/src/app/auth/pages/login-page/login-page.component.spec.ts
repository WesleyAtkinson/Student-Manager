import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { JWT_OPTIONS, JwtHelperService } from '@auth0/angular-jwt';

import { LoginPageComponent } from './login-page.component';

fdescribe('LoginPageComponent', () => {
  let component: LoginPageComponent;
  let fixture: ComponentFixture<LoginPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginPageComponent ],
      imports: [HttpClientTestingModule],
      providers: [
        { provide: JWT_OPTIONS, useValue: JWT_OPTIONS },
        JwtHelperService
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have a form with 2 controls', () => {
    expect(component.loginForm.contains('email')).toBeTruthy();
    expect(component.loginForm.contains('password')).toBeTruthy();
  });

  it('should check that email is required', () => {
    let email = component.loginForm.controls['email'];
    expect(email.valid).toBeFalsy();
    expect(email.errors!['required']).toBeTruthy();
  });

  it('should check that password is required', () => {
    let password = component.loginForm.controls['password'];
    expect(password.valid).toBeFalsy();
    expect(password.errors!['required']).toBeTruthy();
  }); 

  it('should set email and be valid', () => {
    let email = component.loginForm.controls['email'];
    email.setValue('test@gmail.com');
    expect(email.valid).toBeTruthy();
  })

  it('should set password and be valid', () => {
    let password = component.loginForm.controls['password'];
    password.setValue('Password19666');
    expect(password.valid).toBeTruthy();
  })

  it('should set email and be invalid', () => {
    let email = component.loginForm.controls['email'];
    email.setValue('testgmail.com');
    expect(email.valid).toBeFalsy();
  })

  it('should be a valid form when all fields are filled out correctly', () => {
    component.loginForm.controls['email'].setValue('stranger@gmail.com');
    component.loginForm.controls['password'].setValue('Password19666');
    expect(component.loginForm.valid).toBeTruthy();
  })
});
