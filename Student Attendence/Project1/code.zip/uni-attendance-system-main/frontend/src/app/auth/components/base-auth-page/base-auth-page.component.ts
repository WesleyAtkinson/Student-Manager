import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-base-auth-page',
  templateUrl: './base-auth-page.component.html',
  styleUrls: ['./base-auth-page.component.scss']
})
export class BaseAuthPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
