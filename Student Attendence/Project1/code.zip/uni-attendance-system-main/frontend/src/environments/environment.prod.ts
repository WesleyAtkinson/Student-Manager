export const environment = {
  production: true,
  baseApiUrl: 'https://api.staging.monte.red',
};
