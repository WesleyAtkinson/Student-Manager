import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from '../entities/user.entity';
import { Repository } from 'typeorm';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private usersRepository: Repository<User>
  ) {}

  async createUser(email: string, password: string, firstName: string, lastName: string) {
    let user = this.usersRepository.create({
      email,
      firstName,
      lastName,
      password
    })
    user.setPassword(password)
    await this.usersRepository.save(user)
    return user
  }

  findAll(): Promise<User[]> {
    return this.usersRepository.find();
  }

  async findOne(id: number) {
    return await this.usersRepository.findOne({
      where: { id }
    })
  }

  findOneByEmail(email: string) {
    return this.usersRepository.findOne({
      where: { email }
    })
  }

  async remove(id: string): Promise<void> {
    await this.usersRepository.delete(id);
  }

  save(user: User) {
    return this.usersRepository.update(user.id, user);
  }

  getStudents() {
    return this.usersRepository.find({
      where: {
        role: 'student'
      }
    })
  }

  getTeachers() {
    return this.usersRepository.find({
      where: {
        role: 'teacher'
      }
    })
  }

  getAdmins() {
    return this.usersRepository.find({
      where: {
        role: 'admin'
      }
    })
  }
}
