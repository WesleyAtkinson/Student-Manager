import { Controller, Get, Request, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { UsersService } from './users.service';

@Controller('users')
export class UsersController {
  
  constructor(private usersService: UsersService) {}

  @UseGuards(JwtAuthGuard)
  @Get('students')
  getStudents(@Request() req) {
    return this.usersService.getStudents()
  }

  @UseGuards(JwtAuthGuard)
  @Get('teachers')
  getTeachers(@Request() req) {
    return this.usersService.getTeachers()
  }

  @UseGuards(JwtAuthGuard)
  @Get('admins')
  getAdmins(@Request() req) {
    return this.usersService.getAdmins()
  }

}
