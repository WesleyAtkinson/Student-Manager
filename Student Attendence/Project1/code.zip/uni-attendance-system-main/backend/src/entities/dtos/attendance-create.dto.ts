import { IsNotEmpty } from 'class-validator'

export class AttendanceCreateStaffDto {

  @IsNotEmpty()
  userId: number

}

export class AttendanceCreateCodeDto {

  @IsNotEmpty()
  code: string

}
