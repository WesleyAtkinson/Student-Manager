import { IsNotEmpty } from 'class-validator'

export class ClassDto {

  @IsNotEmpty()
  name: string

  students?: number[]

}