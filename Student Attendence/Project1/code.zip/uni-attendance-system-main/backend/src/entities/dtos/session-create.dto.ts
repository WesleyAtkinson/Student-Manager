import { IsNotEmpty } from 'class-validator'

export class SessionCreateDto {

  @IsNotEmpty()
  classId: number

}