import { Entity, Column, PrimaryGeneratedColumn, ManyToMany, OneToMany, ManyToOne, JoinColumn, CreateDateColumn, JoinTable } from 'typeorm'
import { Attendance } from './attendance.entity'
import { Class } from './class.entity'
import { User } from './user.entity'

@Entity()
export class Session {
  @PrimaryGeneratedColumn()
  id: number

  @CreateDateColumn()
  createdAt: Date

  @Column()
  code: string

  @ManyToOne(type => Class, cls => cls.sessions, { eager: true })
  @JoinColumn()
  cls: Class

  @ManyToMany(type => User, user => user.memberOfSessions)
  @JoinTable()
  students: User[]

  @OneToMany(type => Attendance, attendance => attendance.session)
  attended: Attendance[]

  getSession() {
    return {
      id: this.id,
      createdAt: this.createdAt,
      code: this.code
    }
  }
}
