import { Entity, Column, PrimaryGeneratedColumn, ManyToMany, OneToMany, JoinTable } from 'typeorm'
import { Session } from './session.entity'
import { User } from './user.entity'

@Entity()
export class Class {
  @PrimaryGeneratedColumn()
  id: number

  @Column()
  name: string

  @OneToMany(type => Session, session => session.cls)
  sessions: Session[]

  @ManyToMany(type => User, user => user.memberOfClasses)
  @JoinTable() 
  students: User[]

  getClass() {
    return {
      id: this.id,
      name: this.name
    }
  }
}
