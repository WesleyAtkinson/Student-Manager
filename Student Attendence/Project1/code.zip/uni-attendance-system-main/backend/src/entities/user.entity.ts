import { from } from 'rxjs';
import { Entity, Column, PrimaryGeneratedColumn, ManyToMany, OneToMany } from 'typeorm'
import { Attendance } from './attendance.entity'
import { Class } from './class.entity'
import { Session } from './session.entity'

const bcrypt = require('bcrypt');

@Entity()
export class User {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ unique: true })
  email: string

  @Column()
  password: string

  @Column()
  firstName: string

  @Column()
  lastName: string

  @Column({ default: true })
  isActive: boolean

  @Column({ default: 'student' })
  role: 'student' | 'teacher' | 'admin'

  @ManyToMany(type => Class, cl => cl.students)
  memberOfClasses: Class[]

  @ManyToMany(type => Session, session => session.students)
  memberOfSessions: Session[]

  @OneToMany(type => Attendance, attendance => attendance.user)
  attendance: Attendance[]

  checkPassword(pass: string): boolean {
    const match = bcrypt.compare(pass, this.password);

    return match;
  }

  setPassword(password: string) {
    bcrypt.hash(password, 12).then(hash => {
      this.password = hash;
    });
  }

  getProfile() {
    return {
      id: this.id,
      email: this.email,
      firstName: this.firstName,
      lastName: this.lastName,
      isActive: this.isActive,
      role: this.role
    }
  }
}
