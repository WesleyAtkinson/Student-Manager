import { Entity, Column, PrimaryGeneratedColumn, ManyToMany, OneToMany, JoinColumn, ManyToOne, CreateDateColumn } from 'typeorm'
import { Session } from './session.entity'
import { User } from './user.entity'

@Entity()
export class Attendance {
  @PrimaryGeneratedColumn()
  id: number

  @CreateDateColumn()
  createdAt: Date

  @ManyToOne(type => User, user => user.attendance, { eager: true })
  @JoinColumn()
  user: User

  @ManyToOne(type => Session, session => session.attended, { eager: true })
  @JoinColumn()
  session: Session

  getAttendance() {
    return {
      id: this.id
    }
  }
}
