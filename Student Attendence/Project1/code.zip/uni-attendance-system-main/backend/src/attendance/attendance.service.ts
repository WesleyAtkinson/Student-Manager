import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Attendance } from 'src/entities/attendance.entity';
import { Repository } from 'typeorm';

@Injectable()
export class AttendanceService {
  constructor(
    @InjectRepository(Attendance)
    private attendanceRepository: Repository<Attendance>
  ) {}

  async create(details: { sessionId: number, userId: number }) {
    const attendance = this.attendanceRepository.create({
      session: { id: details.sessionId },
      user: { id: details.userId }
    })
    await this.attendanceRepository.save(attendance)

    return attendance
  }

  findAttendance(sessionId: number, userId: number) {
    return this.attendanceRepository.findOne({
      where: {
        session: {
          id: sessionId
        },
        user: {
          id: userId
        }
      }
    })
  }

  findOne(id: number) {
    return this.attendanceRepository.findOne({ where: { id } })
  }

  delete(id: number) {
    return this.attendanceRepository.delete({ id })
  }
}
