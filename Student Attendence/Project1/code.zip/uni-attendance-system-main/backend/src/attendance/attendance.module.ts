import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Attendance } from 'src/entities/attendance.entity';
import { AttendanceService } from './attendance.service';
import { AttendanceController } from './attendance.controller';
import { SessionsModule } from 'src/sessions/sessions.module';

@Module({
  imports: [TypeOrmModule.forFeature([Attendance]), forwardRef(() => SessionsModule)],
  providers: [AttendanceService],
  exports: [AttendanceService],
  controllers: [AttendanceController]
})
export class AttendanceModule {}
