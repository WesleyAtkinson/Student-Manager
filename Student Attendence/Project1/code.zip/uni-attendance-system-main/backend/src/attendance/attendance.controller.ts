import { Body, Controller, Param, Post, Request, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { AttendanceCreateCodeDto } from 'src/entities/dtos/attendance-create.dto';
import { SessionsService } from 'src/sessions/sessions.service';
import { AttendanceService } from './attendance.service';

@Controller('attendance')
export class AttendanceController {
  
  constructor(private sessionService: SessionsService, private attendanceService: AttendanceService) {}

  @UseGuards(JwtAuthGuard)
  @Post()
  async createAttendance(@Request() req, @Body() body: AttendanceCreateCodeDto) {
    const session = await this.sessionService.findByCode(body.code)
    let status = await this.attendanceService.findAttendance(session.id, req.user.id)

    if(!status) {
      status = await this.attendanceService.create({
        sessionId: session.id,
        userId: req.user.id
      })
    }
    return status
  }

}
