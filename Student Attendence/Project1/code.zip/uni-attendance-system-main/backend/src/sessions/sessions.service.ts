import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Session } from 'src/entities/session.entity';
import { Repository } from 'typeorm';

@Injectable()
export class SessionsService {
  constructor(
    @InjectRepository(Session)
    private sessionsRepository: Repository<Session>
  ) {}

  async create(details: { classId: number }) {
    let session = this.sessionsRepository.create({
      cls: { id: details.classId },
      code: Math.floor(Math.random() * 900000).toString()
    })
    await this.sessionsRepository.save(session)

    return session
  }

  findAll() {
    return this.sessionsRepository.find()
  }

  findAllForClass(classId: number) {
    return this.sessionsRepository.find({
      where: {
        cls: { id: classId }
      }
    })
  }

  async findAttendanceForClass(classId: number) {
    return this.sessionsRepository.find({
      where: {
        cls: { id: classId }
      },
      relations: ['attended']
    })
  }

  findOne(id: number) {
    return this.sessionsRepository.findOne({ where: { id }, relations: ['students'] })
  }

  findByCode(code: string) {
    return this.sessionsRepository.findOne({ where: { code }, relations: ['students'] })
  }

  save(session: Session) {
    return this.sessionsRepository.update(session.id, session)
  }
}
