import { Body, Controller, Delete, Get, Param, Post, Query, Request, UseGuards } from '@nestjs/common';
import { AttendanceService } from 'src/attendance/attendance.service';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { AttendanceCreateStaffDto } from 'src/entities/dtos/attendance-create.dto';
import { SessionCreateDto } from 'src/entities/dtos/session-create.dto';
import { UsersService } from 'src/users/users.service';
import { SessionsService } from './sessions.service';

@Controller('sessions')
export class SessionsController {

  constructor(private sessionsService: SessionsService, private attendanceService: AttendanceService, private usersService: UsersService) {}

  @UseGuards(JwtAuthGuard)
  @Get()
  getSessions(@Request() req, @Query('classId') classId: number) {
    return this.sessionsService.findAllForClass(classId)
  }

  @UseGuards(JwtAuthGuard)
  @Get(':id')
  getSession(@Request() req, @Param('id') id: number) {
    return this.sessionsService.findOne(id)
  }

  @UseGuards(JwtAuthGuard)
  @Post()
  createSession(@Request() req, @Body() body: SessionCreateDto) {
    return this.sessionsService.create({
      classId: body.classId
    })
  }

  @UseGuards(JwtAuthGuard)
  @Get(':id/status')
  async getStatus(@Request() req, @Param('id') id: number) {
    const session = await this.sessionsService.findOne(id)
    
    // TODO: add student select
    //const students = session.students
    const students = await this.usersService.getStudents()

    const status = await Promise.all(students.map(async student => {
      const attendance = await this.attendanceService.findAttendance(session.id, student.id)
      return {
        user: student,
        attendance
      }
    }))

    return status
  }

  @UseGuards(JwtAuthGuard)
  @Post(':id/attendance')
  async createAttendance(@Request() req, @Param('id') sessionId: number, @Body() body: AttendanceCreateStaffDto) {
    let status = await this.attendanceService.findAttendance(sessionId, body.userId)

    if(!status) {
      status = await this.attendanceService.create({
        sessionId: sessionId,
        userId: body.userId
      })
    }
    return status
  }

  @UseGuards(JwtAuthGuard)
  @Delete(':sessionId/attendance/:attendanceId')
  async deleteAttendance(@Request() req, @Param('sessionId') sessionId: number, @Param('attendanceId') attendanceId: number) {
    return this.attendanceService.delete(attendanceId)
  }
}
