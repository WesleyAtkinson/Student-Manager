import { Injectable } from '@nestjs/common';
import { JwtService, JwtVerifyOptions } from '@nestjs/jwt';
import { User } from '../entities/user.entity';
import { UsersService } from '../users/users.service';

@Injectable()
export class AuthService {
  constructor(
    private usersService: UsersService,
    private jwtService: JwtService
  ) {}

  async validateUser(email: string, pass: string): Promise<any> {
    const user = await this.usersService.findOneByEmail(email)
    if (user && user.checkPassword(pass)) {
      const { password, ...result } = user
      return result
    }
    return null
  }

  async validateUserPayload(payload: any): Promise<User> {
    const user = await this.usersService.findOne(payload.sub)
    if (user) {
      return user
    }
    return null
  }

  async login(user: User) {
    const payload = {
      sub: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName
    }

    return {
      access_token: this.jwtService.sign(payload)
    }
  }

  verify(token: string, options?: JwtVerifyOptions) {
    return this.jwtService.verify(token, options)
  }
}
