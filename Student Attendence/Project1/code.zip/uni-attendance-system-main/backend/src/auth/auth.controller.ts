import { Controller, UseGuards, Get, Post, Request, Body } from '@nestjs/common';
import { LocalAuthGuard } from './local-auth.guard';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from './jwt-auth.guard';
import { UsersService } from '../users/users.service';
import { UserRegisterDto } from '../entities/dtos/user-register.dto';

@Controller('auth')
export class AuthController {

  constructor(private authService: AuthService, private usersService: UsersService) {}

  @UseGuards(LocalAuthGuard)
  @Post('login')
  async login(@Request() req) {
    return this.authService.login(req.user);
  }

  @UseGuards(JwtAuthGuard)
  @Get('profile')
  getProfile(@Request() req) {
    return req.user.getProfile();
  }

  @Post('register')
  async register(@Request() req, @Body() userInfo: UserRegisterDto) {
    await this.usersService.createUser(userInfo.email, userInfo.password, userInfo.firstName, userInfo.lastName)
    return {
      message: ['New user created']
    }
  }
}
