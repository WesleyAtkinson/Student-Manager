import { CanActivate, ExecutionContext, Injectable } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { Observable } from "rxjs";
import { UsersService } from "src/users/users.service";
import { AuthService } from "./auth.service";
import { jwtConstants } from "./constants";

@Injectable()
export class WsGuard implements CanActivate {
  constructor(private usersService: UsersService, private authService: AuthService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const bearerToken = context.switchToWs().getClient().handshake.headers.authorization.split(' ')[1]
    try {
      const decoded = this.authService.verify(bearerToken, { secret: jwtConstants.secret })
      context.switchToWs().getClient().user = await this.authService.validateUserPayload(decoded)
      return true
    } catch(e) {
      return false
    }
  }
}