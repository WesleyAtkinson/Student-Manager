export const jwtConstants = {
  secret: 'CHANGETHISSECRETKEY_DEVONLY',
}
