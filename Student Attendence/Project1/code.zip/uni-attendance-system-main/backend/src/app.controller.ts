import { Controller, Get, Post, Req, Request, UseGuards } from '@nestjs/common';
import { AppService } from './app.service';
import { JwtAuthGuard } from './auth/jwt-auth.guard';
import { User } from './entities/user.entity';
import { UsersService } from './users/users.service';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService, private usersService: UsersService) {}

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  @UseGuards(JwtAuthGuard)
  @Post('toggle-role')
  toggleRole(@Request() req): string {
    const user = req.user as User

    if(user.role === 'student') {
      user.role = 'teacher'
    } else {
      user.role = 'student'
    }

    this.usersService.save(user)
    return '{}'
  }
}
