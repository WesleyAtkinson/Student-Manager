import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Class } from 'src/entities/class.entity';
import { ClassesService } from './classes.service';
import { ClassesController } from './classes.controller';
import { SessionsModule } from 'src/sessions/sessions.module';
import { UsersModule } from 'src/users/users.module';

@Module({
  imports: [TypeOrmModule.forFeature([Class]), SessionsModule, UsersModule],
  providers: [ClassesService],
  exports: [ClassesService],
  controllers: [ClassesController]
})
export class ClassesModule {}
