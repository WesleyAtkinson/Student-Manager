import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { from } from 'rxjs';
import { Class } from 'src/entities/class.entity';
import { User } from 'src/entities/user.entity';
import { Connection, Repository } from 'typeorm';

@Injectable()
export class ClassesService {
  constructor(
    @InjectRepository(Class)
    private classesRepository: Repository<Class>,
    private connection: Connection
  ) {}

  async create(options: { name: string }) {
    let cls = this.classesRepository.create({
      name: options.name
    })
    await this.classesRepository.save(cls)

    return cls
  }

  async updateOne(cls: Class) {
    return from(this.classesRepository.update(cls.id, cls));
  }

  async deleteOne(cls: Class) {
    return from(this.classesRepository.remove(cls));
  }

  findAll() {
    return this.classesRepository.find({
      relations: ['students']
    })
  }

  findOne(id: number) {
    return this.classesRepository.findOne({ where: { id } })
  }

  save(cls: Class) {
    return this.classesRepository.update(cls.id, cls)
  }

  async addStudent(cls: Class, student: User) {
    cls.students.push(student)
    await this.classesRepository.save(cls)
  }
}
