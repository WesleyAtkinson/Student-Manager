import { Body, Controller, Delete, Get, Param, Post, Put, Request, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { Class } from 'src/entities/class.entity';
import { ClassDto } from 'src/entities/dtos/class.dto';
import { SessionsService } from 'src/sessions/sessions.service';
import { UsersService } from 'src/users/users.service';
import { ClassesService } from './classes.service';

@Controller('classes')
export class ClassesController {

  constructor(private classesService: ClassesService, private sessionsService: SessionsService, private usersService: UsersService) {}

  @UseGuards(JwtAuthGuard)
  @Get()
  getClasses(@Request() req) {
    return this.classesService.findAll()
  }

  @UseGuards(JwtAuthGuard)
  @Get(':id')
  getClass(@Request() req, @Param('id') id: number) {
    return this.classesService.findOne(id)
  }

  @UseGuards(JwtAuthGuard)
  @Post()
  createClass(@Request() req, @Body() body: ClassDto) {
    return this.classesService.create({
      name: body.name
    })
  }

  @UseGuards(JwtAuthGuard)
  @Put(':id')
  async updateClass(@Request() req, @Param('id') id: number, @Body() body: ClassDto) {
    let cls = await this.classesService.findOne(id)

    cls.name = body.name
    this.classesService.updateOne(cls)

    /*if(body.students) {
      for(let student of body.students) {
        const user = await this.usersService.findOne(student)
        await this.classesService.addStudent(cls, user)
      }
    }*/

    return cls
  }

  @UseGuards(JwtAuthGuard)
  @Delete(':id')
  async deleteClass(@Request() req, @Param('id') id: number) {
    let cls = await this.classesService.findOne(id)
    await this.classesService.deleteOne(cls)

    return
  }

  @UseGuards(JwtAuthGuard)
  @Get(':id/attendance')
  async getClassAttendance(@Request() req, @Param('id') classId: number) {
    let sessions = await this.sessionsService.findAttendanceForClass(classId)
    if(sessions.length === 0) return { attendance: 0 }

    let sessionsLength = sessions.length
    let attendedCount = 0
  
    for(let session of sessions) {
      for (let attended of session.attended) {
        if(attended.user.id == req.user.id) {
          attendedCount++
        }
      }
    }

    let attendance = attendedCount / sessionsLength * 100
    return { personalAttendance: attendance, classAttendance: attendance }
  }

  @UseGuards(JwtAuthGuard)
  @Get(':id/student-attendance') //return list of students and their attendance
  async getClassStudentAttendance(@Request() req, @Param('id') classId: number) {
    let sessions = await this.sessionsService.findAttendanceForClass(classId)
    if(sessions.length === 0) return { attendance: 0 }

    let sessionsLength = sessions.length

    let students = []

    for(let session of sessions) {
      for (let attended of session.attended) {
        if (!students.find(student => student.student.id === attended.user.id)) {
          students.push({student: attended.user, attendedCount: 0})
        }
        if (students.find(student => student.student.id == attended.user.id)) {
          let index = students.findIndex((student => student.student.id == attended.user.id));
          students[index].attendedCount++
        }
      }
    }

    for (let student of students) {
      student.attendance = student.attendedCount / sessionsLength * 100
    }
  
    return students
  }
}
